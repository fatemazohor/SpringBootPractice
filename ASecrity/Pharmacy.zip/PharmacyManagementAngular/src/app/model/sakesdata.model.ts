interface SalesData {
    medicineName: string;
    quantity: number;
    totalPrice: number;
  }
  
  
 
  