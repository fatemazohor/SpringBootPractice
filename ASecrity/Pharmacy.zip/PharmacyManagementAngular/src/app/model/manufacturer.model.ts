export class Manufacturer {
   
    id?: number;
    name?: string;
    contactPersonName?: string;
    contactPersonCellNo?: string;
    email?: string;
    address?: string;


}