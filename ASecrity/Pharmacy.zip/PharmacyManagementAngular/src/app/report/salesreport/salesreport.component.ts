import { Component, OnInit } from '@angular/core';
import { SalesService } from '../../service/sales.service';

@Component({
  selector: 'app-salesreport',
  templateUrl: './salesreport.component.html',
  styleUrl: './salesreport.component.css'
})
export class SalesreportComponent {

  startDate!: Date;
  endDate!: Date;
  salesReport: any;

  constructor(private salesService: SalesService) { }

  generateReport() {
    if (this.startDate && this.endDate) {
      this.salesService.getSalesReport(this.startDate, this.endDate).subscribe(
        (data) => {
          this.salesReport = data;
          console.log(this.salesReport)
        },
        (error) => {
          console.log(error);
        }
      );
    }
  }
  
  printReport(): void {
    window.print();
  }

}
