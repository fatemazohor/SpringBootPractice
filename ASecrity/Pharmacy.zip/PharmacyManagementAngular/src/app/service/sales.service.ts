import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Sales } from '../model/sales.model';

@Injectable({
  providedIn: 'root'
})
export class SalesService {

  private baseUrl = 'http://localhost:8089/api/sales'; // URL to your API endpoint


  constructor(private http: HttpClient) { }

  getAllSales(): Observable<any[]> {
    return this.http.get<any[]>(this.baseUrl);
  }

  addSale(sales: Sales): Observable<Sales> {
    return this.http.post<any>(this.baseUrl, sales);
  }


  getSalesReport(startDate: Date, endDate: Date): Observable<any[]> {
    const url = `${this.baseUrl}/salesReport?startDate=${startDate}&endDate=${endDate}`;

    return this.http.get<any[]>(url);
  }
 
  
  



}
