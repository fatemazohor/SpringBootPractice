package com.example.pharmacyManagement.restcontroller;


import com.example.pharmacyManagement.Service.MedicineService;
import com.example.pharmacyManagement.model.*;
import com.example.pharmacyManagement.repository.GenericRepository;
import com.example.pharmacyManagement.repository.IMedicineRepository;
import com.example.pharmacyManagement.repository.IStockRepository;
import com.example.pharmacyManagement.repository.ManufacturerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/medicine")
@CrossOrigin("*")
public class MedicineRestController {

    @Autowired
    IMedicineRepository medicineRepository;
    @Autowired
    private GenericRepository genericRepository;
    @Autowired
    private ManufacturerRepository manufacturerRepository;
    @Autowired
    private IStockRepository stockRepository;

    @Autowired
    private MedicineService medicineService;



    @GetMapping()
    public Optional<List<Medicine>> getAllProduct(){

        return Optional.of(medicineRepository.findAll());
    }


    @PostMapping
    public ResponseEntity<Medicine> addMedicine(@RequestBody Medicine medicine ){
        String genericName=medicine.getGeneric().getName();
        String manufacturerName=medicine.getManufacturer().getName();
        Generic generic=genericRepository.findByName(genericName);
        Manufacturer manufacturer=manufacturerRepository.findByName(manufacturerName);
        medicine.setGeneric(generic);
        medicine.setManufacturer(manufacturer);
        Medicine saveMedicine=medicineRepository.save(medicine);
        medicineService.updateStock(medicine);
        return  ResponseEntity.ok(saveMedicine);

    }


}
