package com.example.pharmacyManagement.repository;

import com.example.pharmacyManagement.model.Medicine;
import com.example.pharmacyManagement.model.Product;
import com.example.pharmacyManagement.model.Stock;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IStockRepository extends JpaRepository<Stock,Integer> {
    Stock findByMedicine(Medicine medicine);

}
