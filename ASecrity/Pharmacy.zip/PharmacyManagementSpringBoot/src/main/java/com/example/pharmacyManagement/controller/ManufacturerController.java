package com.example.pharmacyManagement.controller;


import com.example.pharmacyManagement.model.Generic;
import com.example.pharmacyManagement.model.Manufacturer;
import com.example.pharmacyManagement.repository.GenericRepository;
import com.example.pharmacyManagement.repository.ManufacturerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class ManufacturerController {

    @Autowired
    ManufacturerRepository manufacturerRepository;

    @GetMapping("/manufacturer")
    public String generic(Model model) {

        List<Manufacturer> manufacturerList=manufacturerRepository.findAll();
        model.addAttribute("manufacturerList", manufacturerList);

        return "manufacturerlist";
    }

    @GetMapping("/manufactureradd")
    public String genericForm(Model model) {

        model.addAttribute("manufacturer", new Manufacturer());

        return "manufactureradd";
    }

    @PostMapping("/manufactureradd")
    public String genericadd(@ModelAttribute("manufactureradd") Manufacturer manufacturer) {

        manufacturerRepository.save(manufacturer);

        return "redirect:/manufacturer";
    }

}
