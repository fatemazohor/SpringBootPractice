package com.example.pharmacyManagement.restcontroller;

import com.example.pharmacyManagement.Service.SaleService;
import com.example.pharmacyManagement.model.Medicine;
import com.example.pharmacyManagement.model.Product;
import com.example.pharmacyManagement.model.Sales;
import com.example.pharmacyManagement.model.Stock;
import com.example.pharmacyManagement.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/sales")
@CrossOrigin("*")
public class SalesRestController {
    @Autowired
    private SaleService saleService;
    @Autowired
    private SalesRepository salesRepository;

    @Autowired
    private IStockRepository stockRepository;

    @Autowired
    IMedicineRepository medicineRepository;



    @GetMapping()
    public Optional<List<Sales>> getAllSales(){

        return Optional.of(salesRepository.findAll());
    }


    @PostMapping
    public ResponseEntity<Sales> addSale(@RequestBody Sales sale) {
        Sales newSale = saleService.addSale(sale);
        return new ResponseEntity<>(newSale, HttpStatus.CREATED);
    }


//    @GetMapping("/salesReport")
//    public ResponseEntity<Map<Date, Double>> generateSalesReport(
//            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
//            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {
//
//        Map<Date, Double> report = saleService.generateReportByDate(startDate, endDate);
//        return new ResponseEntity<>(report, HttpStatus.OK);
//    }


//    @GetMapping("/salesReport")
//    public ResponseEntity<Map<LocalDate, List<Sales>>> generateSalesReport(
//            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
//            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {
//
//        Map<LocalDate, List<Sales>> report = saleService.generateReportByDate(Date.valueOf(startDate), Date.valueOf(endDate));
//        return new ResponseEntity<>(report, HttpStatus.OK);
//    }

    @GetMapping("/salesReport")
    public ResponseEntity<Map<LocalDate, List<Sales>>> generateSalesReport(
            @RequestParam("startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate startDate,
            @RequestParam("endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate endDate) {

        Map<LocalDate, List<Sales>> report = saleService.generateReportByDate(startDate, endDate);
        return new ResponseEntity<>(report, HttpStatus.OK);
    }


}
