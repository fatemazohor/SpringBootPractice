package com.example.pharmacyManagement.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.sql.Date;


@Entity
@Data
@ToString
public class Medicine {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String name;
    private int quantity;
    private double unitPrice;
    private Date productionDate;
    private Date expiryDate;

    @ManyToOne
    @JoinColumn(
            name = "generic_id"
    )
    Generic generic;

    @ManyToOne
    @JoinColumn(
            name = "manufacturer_id"
    )
    Manufacturer manufacturer;


    public Medicine(String name, int quantity, double unitPrice, Date productionDate, Date expiryDate, Generic generic, Manufacturer manufacturer) {
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.productionDate = productionDate;
        this.expiryDate = expiryDate;
        this.generic = generic;
        this.manufacturer = manufacturer;
    }

    public Medicine(int id, String name, int quantity, double unitPrice, Date productionDate, Date expiryDate, Generic generic, Manufacturer manufacturer) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.productionDate = productionDate;
        this.expiryDate = expiryDate;
        this.generic = generic;
        this.manufacturer = manufacturer;
    }

    public Medicine(int id) {
        this.id = id;
    }
    public Medicine() {

    }


}
