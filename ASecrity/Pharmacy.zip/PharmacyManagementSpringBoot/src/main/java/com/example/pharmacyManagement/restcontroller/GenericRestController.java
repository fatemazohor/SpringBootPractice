package com.example.pharmacyManagement.restcontroller;

import com.example.pharmacyManagement.model.Generic;
import com.example.pharmacyManagement.repository.GenericRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/generic")
@CrossOrigin("*")
@RequiredArgsConstructor
public class GenericRestController {

    private final GenericRepository genericRepository;

    @GetMapping()
    public List<Generic> getAllGeneric() {
        return genericRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Generic> getGenericById(@PathVariable int id) {
        Optional<Generic> generic = genericRepository.findById(id);
        return generic.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping()
    public ResponseEntity<Generic> createGeneric(@Validated @RequestBody Generic generic) {
        Generic createdGeneric = genericRepository.save(generic);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdGeneric);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Generic> updateGeneric(@PathVariable int id, @Validated @RequestBody Generic genericDetails) {
        Optional<Generic> optionalGeneric = genericRepository.findById(id);
        if (optionalGeneric.isPresent()) {
            Generic generic = optionalGeneric.get();
            generic.setName(genericDetails.getName());
            // Set other fields to update as necessary
            Generic updatedGeneric = genericRepository.save(generic);
            return ResponseEntity.ok(updatedGeneric);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteGeneric(@PathVariable int id) {
        Optional<Generic> generic = genericRepository.findById(id);
        if (generic.isPresent()) {
            genericRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
