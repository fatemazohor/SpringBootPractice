package com.example.pharmacyManagement.repository;

import com.example.pharmacyManagement.model.Generic;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GenericRepository extends JpaRepository <Generic,Integer> {

    Generic findByName(String name);

}
