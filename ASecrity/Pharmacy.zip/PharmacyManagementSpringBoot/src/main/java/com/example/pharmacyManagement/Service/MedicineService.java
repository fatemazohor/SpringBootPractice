package com.example.pharmacyManagement.Service;

import com.example.pharmacyManagement.model.Medicine;
import com.example.pharmacyManagement.model.Stock;
import com.example.pharmacyManagement.repository.IMedicineRepository;
import com.example.pharmacyManagement.repository.IStockRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MedicineService {

    private final IMedicineRepository medicineRepository;
    private final IStockRepository  stockRepository;

    public void updateStock(Medicine medicine) {
        Stock stock = stockRepository.findByMedicine(medicine);
        if (stock != null) {
            stock.setTotalQuantity(stock.getTotalQuantity() + medicine.getQuantity());
            double totalPrice=medicine.getQuantity()*medicine.getUnitPrice();
            stock.setTotalPrice(stock.getTotalPrice()+totalPrice);
            stockRepository.save(stock);
        } else {
            // Create new stock entry if it doesn't exist
            Stock newStock = new Stock();
            newStock.setMedicine(medicine);
            newStock.setTotalQuantity(medicine.getQuantity());
            double totalPrice=medicine.getQuantity()*medicine.getUnitPrice();
            newStock.setTotalPrice(newStock.getTotalPrice()+totalPrice);
            stockRepository.save(newStock);
        }
    }

}
