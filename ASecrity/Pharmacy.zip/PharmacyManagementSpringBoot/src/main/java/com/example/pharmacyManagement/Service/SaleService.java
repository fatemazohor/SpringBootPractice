package com.example.pharmacyManagement.Service;


import com.example.pharmacyManagement.model.Medicine;
import com.example.pharmacyManagement.model.Sales;
import com.example.pharmacyManagement.model.Stock;
import com.example.pharmacyManagement.repository.IStockRepository;
import com.example.pharmacyManagement.repository.SalesRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SaleService {


    private  final SalesRepository salesRepository;
    private final IStockRepository stockRepository;




    public Sales addSale(Sales sale) {
        // Update stock
        updateStock(sale.getMedicine(), sale.getQuantitySold());

        // Add sale
        return salesRepository.save(sale);
    }

    // Method to update stock
    private void updateStock(Medicine medicine, double quantitySold) {
        Stock stock = stockRepository.findByMedicine(medicine);
        if (stock != null) {
            double updatedQuantity = stock.getTotalQuantity() - quantitySold;
            stock.setTotalQuantity(updatedQuantity);
            stockRepository.save(stock);
        } else {
            // Handle stock not found for the medicine
            // You may want to throw an exception or handle it based on your application logic
        }
    }


    public Map<LocalDate, List<Sales>> generateReportByDate(LocalDate startDate, LocalDate endDate) {
        List<Sales> salesList = salesRepository.findBySaleDateBetween(startDate, endDate);

        Map<LocalDate, List<Sales>> report = new HashMap<>();
        for (Sales sale : salesList) {
            LocalDate date = sale.getSaleDate().toLocalDate(); // Convert Date to LocalDate

            // If the date already exists in the report, add the sale to the existing list
            if (report.containsKey(date)) {
                report.get(date).add(sale);
            } else {
                List<Sales> sales = new ArrayList<>();
                sales.add(sale);
                report.put(date, sales);
            }
        }

        return report;
    }

}
