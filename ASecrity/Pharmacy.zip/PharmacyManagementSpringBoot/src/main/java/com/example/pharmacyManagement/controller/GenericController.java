package com.example.pharmacyManagement.controller;


import com.example.pharmacyManagement.model.Generic;
import com.example.pharmacyManagement.repository.GenericRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller

public class GenericController {

    @Autowired
    GenericRepository genericRepository;

    @GetMapping("/generic")
    public String generic(Model model) {

        List<Generic> genericList=genericRepository.findAll();
        model.addAttribute("genericList", genericList);

        return "genericlist";
    }

    @GetMapping("/genericadd")
    public String genericForm(Model model) {

        model.addAttribute("generic", new Generic());

        return "genericladd";
    }

    @PostMapping("/genericadd")
    public String genericadd(@ModelAttribute("generic") Generic generic) {

        genericRepository.save(generic);

        return "redirect:/generic";
    }



}
