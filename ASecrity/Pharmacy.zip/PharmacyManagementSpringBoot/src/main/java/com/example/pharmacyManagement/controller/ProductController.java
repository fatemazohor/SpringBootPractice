package com.example.pharmacyManagement.controller;

import com.example.pharmacyManagement.model.Generic;
import com.example.pharmacyManagement.model.Manufacturer;
import com.example.pharmacyManagement.model.Medicine;
import com.example.pharmacyManagement.model.Product;
import com.example.pharmacyManagement.repository.GenericRepository;
import com.example.pharmacyManagement.repository.IMedicineRepository;
import com.example.pharmacyManagement.repository.ManufacturerRepository;
import com.example.pharmacyManagement.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Optional;

@Controller

public class ProductController {


    @Autowired
    GenericRepository genericRepository;

    @Autowired
    ManufacturerRepository manufacturerRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    IMedicineRepository medicineRepository;

    @RequestMapping("/product")
    public String allProduct(Model model){
        List<Product> productList=productRepository.findAll();

        model.addAttribute("productList", productList);
        return "productlist";

    }

    @RequestMapping("/addproduct")
    public String addProductform(Model model){

        List<Medicine>  medicineList=medicineRepository.findAll();

        model.addAttribute("product", new Product());

        model.addAttribute("medicineList", medicineList);
//        model.addAttribute("genericList", genericList);

        return "addProduct";

    }
    @RequestMapping("/save")
    public String addProduct(@ModelAttribute("product") Product product){

        productRepository.save(product);

        return "redirect:/product";

    }

   @PostMapping("/editproduct/{id}")
    public String findProductToEdit (@PathVariable int id, Model model){
       Optional <Product> productdata= productRepository.findById(id);
        model.addAttribute("product",productdata);
        return "/addProduct";
    }



}
