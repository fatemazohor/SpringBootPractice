package com.example.pharmacyManagement.restcontroller;

import com.example.pharmacyManagement.model.*;
import com.example.pharmacyManagement.repository.*;
import org.apache.catalina.util.ErrorPageSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/product")
public class ProductRestController {
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private GenericRepository genericRepository;
    @Autowired
    private ManufacturerRepository manufacturerRepository;

    @Autowired
    private IStockRepository stockRepository;

    @Autowired
    IMedicineRepository medicineRepository;



    @GetMapping()
    public Optional<List<Product>> getAllProduct(){

        return Optional.of(productRepository.findAll());
    }


//    @PostMapping
//    public ResponseEntity<Product> addProduct(@RequestBody Product product ){
//
//        List<Medicine> medicineList=medicineRepository.findAll();
//
//
//        String medicineName=product.getMedicine().getName();
//
//
//        Medicine medicine=medicineRepository.findByName(medicineName);
//
//        product.setMedicine(medicine);
//        product.calculateTotalPrice();
//        Product saveProduct=productRepository.save(product);
//
//        Optional<Stock> optionalStock  = stockRepository.findById(saveProduct.getMedicine().getId());
//
//
//        if (optionalStock.isPresent()) {
//            // Update existing stock
//            Stock stock = optionalStock.get();
//            // You can update the totalProduct or totalPrice based on your requirements
//            stock.setId(saveProduct.getMedicine().getId());
//            stock.setTotalProduct(stock.getTotalProduct() + saveProduct.getQuantity()); // Example: Increment totalProduct by 1
//            stock.setTotalPrice(stock.getTotalPrice() + saveProduct.getTotalPrice()); // Example: Increment totalProduct by 1
//            stockRepository.save(stock);
//        }
//
//        return  null;
//
//    }





}
