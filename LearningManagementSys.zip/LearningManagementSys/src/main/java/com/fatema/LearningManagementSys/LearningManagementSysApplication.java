package com.fatema.LearningManagementSys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningManagementSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningManagementSysApplication.class, args);
	}

}
