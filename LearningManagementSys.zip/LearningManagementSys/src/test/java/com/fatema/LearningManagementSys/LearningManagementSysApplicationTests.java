package com.fatema.LearningManagementSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningManagementSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
