package com.example.SpringBootP3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootP3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
