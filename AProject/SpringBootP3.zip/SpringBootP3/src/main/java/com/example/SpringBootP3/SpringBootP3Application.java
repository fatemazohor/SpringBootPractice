package com.example.SpringBootP3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootP3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootP3Application.class, args);
	}

}
