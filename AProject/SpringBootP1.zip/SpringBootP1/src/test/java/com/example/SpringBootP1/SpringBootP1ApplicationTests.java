package com.example.SpringBootP1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootP1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
