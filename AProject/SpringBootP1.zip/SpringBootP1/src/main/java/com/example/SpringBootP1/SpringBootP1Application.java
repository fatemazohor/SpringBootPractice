package com.example.SpringBootP1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootP1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootP1Application.class, args);
	}

}
